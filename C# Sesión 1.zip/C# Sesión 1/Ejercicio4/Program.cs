// Volumen de un tanque rectangular

int longitud;
int ancho;
int altura;
int volumen;

Console.WriteLine("Ingrese la longitud del tanque en metros:");
longitud = Convert.ToInt32(Console.ReadLine());

Console.WriteLine("Ingrese el ancho del tanque en metros:");
ancho = Convert.ToInt32(Console.ReadLine());

Console.WriteLine("Ingrese la altura del tanque en metros:");
altura = Convert.ToInt32(Console.ReadLine());

volumen = longitud * ancho * altura;

Console.WriteLine("El volumen del tanque es: " + volumen + " m3");