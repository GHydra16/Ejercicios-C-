// Área en manzanas de un terreno rectangular

int longitud;
int ancho = 5;
int areaVaras2;
int areaManzanas;

Console.WriteLine("Ingrese la longitud del terreno en varas:");
longitud = Convert.ToInt32(Console.ReadLine());

areaVaras2 = longitud * ancho;
areaManzanas = areaVaras2 / 1428; // entero

Console.WriteLine("El área del terreno es: " + areaManzanas + " manzanas");