// Producción de leche en baldes (1 balde = 20 litros)

int litrosPorVaca;
int vacas;
int totalLitros;
int baldes;

Console.WriteLine("Ingrese el volumen promedio por vaca (en litros):");
litrosPorVaca = Convert.ToInt32(Console.ReadLine());

Console.WriteLine("Ingrese el número total de vacas ordeñadas:");
vacas = Convert.ToInt32(Console.ReadLine());

totalLitros = litrosPorVaca * vacas;
baldes = totalLitros / 20;

Console.WriteLine("La producción total es de " + baldes + " baldes de leche");