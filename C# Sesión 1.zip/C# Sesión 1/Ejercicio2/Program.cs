// Tiempo total de viaje Managua - Granada (distancia fija 40 km)

int velocidad;
int distancia = 40;
int tiempo;

Console.WriteLine("Ingrese la velocidad promedio en km/h:");
velocidad = Convert.ToInt32(Console.ReadLine());

tiempo = distancia / velocidad;

Console.WriteLine("El tiempo total de viaje es: " + tiempo + " horas");