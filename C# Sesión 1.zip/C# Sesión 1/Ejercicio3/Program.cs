// Distancia total recorrida por un ciclista

int velocidad;
int tiempo;
int distancia;

Console.WriteLine("Ingrese la velocidad promedio en km/h:");
velocidad = Convert.ToInt32(Console.ReadLine());

Console.WriteLine("Ingrese el tiempo recorrido en horas:");
tiempo = Convert.ToInt32(Console.ReadLine());

distancia = velocidad * tiempo;

Console.WriteLine("La distancia recorrida es: " + distancia + " km");