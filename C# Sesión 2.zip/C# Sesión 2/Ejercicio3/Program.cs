// Evaluar calificación con if: aprobado, recuperación o reprobado

int nota;
Console.WriteLine("Ingrese la calificación del estudiante:");
nota = Convert.ToInt32(Console.ReadLine());

if (nota >= 70)
{
    Console.WriteLine("Aprobado");
}
else if (nota >= 50)
{
    Console.WriteLine("Recuperación");
}
else
{
    Console.WriteLine("Reprobado");
}