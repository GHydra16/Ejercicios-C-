// Repetir el ejercicio de la nota pero usando switch con rangos aproximados

int nota;
Console.WriteLine("Ingrese la calificación del estudiante:");
nota = Convert.ToInt32(Console.ReadLine());

switch (nota / 10) // se divide entre 10 para agrupar por decenas
{
    case 10:
    case 9:
    case 8:
    case 7:
        Console.WriteLine("Aprobado");
        break;
    case 6:
    case 5:
        Console.WriteLine("Recuperación");
        break;
    default:
        Console.WriteLine("Reprobado");
        break;
}