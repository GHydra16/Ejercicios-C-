// Determinar si un número es positivo, negativo o cero usando if

int num;

Console.WriteLine("Ingrese un número:");
num = Convert.ToInt32(Console.ReadLine());

if (num > 0)
{
    Console.WriteLine("El número es positivo");
}
else if (num < 0)
{
    Console.WriteLine("El número es negativo");
}
else
{
    Console.WriteLine("El número es cero");
}